function replaceSpaces(value) {
    return value.replace(/\s/g, '');
}

console.log(replaceSpaces('But you were living in another world tryin\' to get your message through'));